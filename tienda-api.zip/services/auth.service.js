import jwt from 'jsonwebtoken'
import dotenv from 'dotenv'

dotenv.config()

const DUMMY_USER = {
  email: 'admin@tienda.com',
  password: '123456',
}

export const login = (email, password) => {
  if (email === DUMMY_USER.email && password === DUMMY_USER.password) {
    return jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1h' })
  }
  return null
}
