import jwt from 'jsonwebtoken';

const MOCK_USER = {
  username: 'admin',
  password: 'admin123',
};

export const loginUserService = async ({ username, password }) => {
  if (username === MOCK_USER.username && password === MOCK_USER.password) {
    const token = jwt.sign({ username }, process.env.JWT_SECRET, { expiresIn: '1h' });
    return token;
  }
  return null;
};