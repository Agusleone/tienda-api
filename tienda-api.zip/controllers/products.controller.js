import * as productService from '../services/products.service.js'

export const getAllProducts = async (req, res) => {
  const products = await productService.getAll()
  res.json(products)
}

export const getProductById = async (req, res) => {
  const product = await productService.getById(req.params.id)
  product ? res.json(product) : res.status(404).json({ error: 'No encontrado' })
}

export const createProduct = async (req, res) => {
  try {
    const created = await productService.create(req.body)
    res.status(201).json(created)
  } catch (e) {
    res.status(400).json({ error: 'Error al crear producto' })
  }
}

export const deleteProduct = async (req, res) => {
  try {
    await productService.remove(req.params.id)
    res.status(204).send()
  } catch (e) {
    res.status(500).json({ error: 'Error al eliminar producto' })
  }
}
