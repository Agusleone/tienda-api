import * as authService from '../services/auth.service.js'

export const loginUser = async (req, res) => {
  const { email, password } = req.body
  const token = authService.login(email, password)

  if (token) res.json({ token })
  else res.status(401).json({ error: 'Credenciales inválidas' })
}
