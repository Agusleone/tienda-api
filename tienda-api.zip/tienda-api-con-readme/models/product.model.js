import {
  collection, getDocs, getDoc, addDoc, deleteDoc, doc,
} from 'firebase/firestore';
import db from '../config/firebase.config.js';

const collectionName = 'products';

export const getAllProductsDB = async () => {
  const productsRef = collection(db, collectionName);
  const snapshot = await getDocs(productsRef);
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
};

export const getProductByIdDB = async (id) => {
  const productRef = doc(db, collectionName, id);
  const snapshot = await getDoc(productRef);
  if (!snapshot.exists()) return null;
  return { id: snapshot.id, ...snapshot.data() };
};

export const createProductDB = async (productData) => {
  const productsRef = collection(db, collectionName);
  const docRef = await addDoc(productsRef, productData);
  return { id: docRef.id, ...productData };
};

export const deleteProductDB = async (id) => {
  const productRef = doc(db, collectionName, id);
  const snapshot = await getDoc(productRef);
  if (!snapshot.exists()) return false;
  await deleteDoc(productRef);
  return true;
};