import { loginUserService } from '../services/auth.service.js';
export const loginUser = async (req, res) => {
  try {
    const token = await loginUserService(req.body);
    if (!token) return res.status(401).json({ error: 'Credenciales inválidas' });
    res.json({ token });
  } catch (error) {
    res.status(500).json({ error: 'Error al iniciar sesión' });
  }
};