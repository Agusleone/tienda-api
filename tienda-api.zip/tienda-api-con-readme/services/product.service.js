import {
  getAllProductsDB,
  getProductByIdDB,
  createProductDB,
  deleteProductDB,
} from '../models/product.model.js';

export const getAllProductsService = () => getAllProductsDB();
export const getProductByIdService = (id) => getProductByIdDB(id);
export const createProductService = (productData) => createProductDB(productData);
export const deleteProductService = (id) => deleteProductDB(id);