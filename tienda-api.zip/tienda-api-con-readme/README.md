# 🛒 API REST para Gestión de Productos - Proyecto Final

Esta es una API REST desarrollada con **Node.js** y **Express**, conectada a una base de datos **Firestore (Firebase)**. Permite a una tienda oficial gestionar productos mediante operaciones CRUD, protegidas con autenticación JWT.

---

## 🚀 Funcionalidades

- 🔐 Login con credenciales fijas (usuario mock)
- 🔄 CRUD de productos
- 🧰 Conexión a Firestore (Firebase)
- ✅ Rutas protegidas con JWT
- 📦 Estructura escalable con capas: Rutas, Controladores, Servicios y Modelos
- 🧱 Manejo completo de errores HTTP

---

## 📁 Estructura del Proyecto

```
project-root/
│
├── config/                # Configuración de Firebase
├── controllers/           # Lógica de negocio
├── models/                # Acceso a Firestore
├── routes/                # Endpoints de la API
├── services/              # Servicios para controladores
├── middlewares/           # Autenticación JWT
├── .env                   # Variables de entorno
├── index.js               # Punto de entrada
└── README.md              # Documentación del proyecto
```

---

## 📦 Instalación

```bash
git clone <repositorio>
cd tienda-api
npm install
```

---

## ⚙️ Configuración

Crear un archivo `.env` en la raíz con las siguientes variables:

```env
PORT=3000
JWT_SECRET=tu_secreto_jwt

FIREBASE_API_KEY=...
FIREBASE_AUTH_DOMAIN=...
FIREBASE_PROJECT_ID=...
FIREBASE_STORAGE_BUCKET=...
FIREBASE_MESSAGING_SENDER_ID=...
FIREBASE_APP_ID=...
```

Podés obtener estas credenciales al crear un proyecto en Firebase y configurar Firestore.

---

## ▶️ Ejecución

```bash
npm run start
```

La API estará corriendo en:  
**http://localhost:3000**

---

## 🧪 Endpoints

### 🔐 Autenticación

`POST /auth/login`

**Body:**

```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Devuelve:**
```json
{ "token": "..." }
```

---

### 📦 Productos

#### `GET /api/products`  
Devuelve todos los productos (pública)

#### `GET /api/products/:id`  
Devuelve un producto por ID (pública)

#### `POST /api/products/create`  
Crea un producto (requiere token)

**Headers:**  
`Authorization: Bearer <token>`

**Body:**
```json
{
  "name": "Zapatillas",
  "price": 99.99,
  "stock": 10,
  "category": "calzado"
}
```

#### `DELETE /api/products/:id`  
Elimina un producto (requiere token)

---

## ⚠️ Manejo de Errores

| Código | Descripción |
|--------|-------------|
| 400    | Error en los datos enviados |
| 401    | Token no enviado |
| 403    | Token inválido o expirado |
| 404    | Ruta o recurso no encontrado |
| 500    | Error interno del servidor |

---

## 📌 Notas

- El login actual utiliza un usuario **mock**: `admin / admin123`
- Firestore debe tener una colección llamada **products**
- El proyecto usa **ESModules** (`"type": "module"` en `package.json`)

---

## 🧑‍💻 Autor

- Proyecto realizado por [Agustin Leone]
